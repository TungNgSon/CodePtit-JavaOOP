/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThucHanh1.Bai12;

/**
 *
 * @author Moment
 */
public class Film {
    private String ftype;
    public Film(String ftype)
    {
        this.ftype=ftype;
    }
    public String getType()
    {
        return this.ftype;
    }
}
